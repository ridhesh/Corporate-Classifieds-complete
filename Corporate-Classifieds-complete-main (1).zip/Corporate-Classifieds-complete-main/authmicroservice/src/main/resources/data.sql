insert into user(empid,emp_username,emp_password) values (1,'john','john');
insert into user(empid,emp_username,emp_password) values (2,'jessy','jessy');
insert into user(empid,emp_username,emp_password) values (3,'riya','riya');
insert into user(empid,emp_username,emp_password) values (4,'maya','maya');
insert into user(empid,emp_username,emp_password) values (5,'arya','arya');