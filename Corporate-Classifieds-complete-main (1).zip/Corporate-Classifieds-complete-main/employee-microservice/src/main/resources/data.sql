insert into employee(emp_id,emp_age, emp_contact, emp_department, emp_email, emp_gender, emp_name) values(1, 25, 1234567980, 'IT','john@gmail.com','Male','john');
insert into employee(emp_id,emp_age, emp_contact, emp_department, emp_email, emp_gender, emp_name) values(2, 25, 1234567980, 'Accounts','jessy@gmail.com','Female','jessy');
insert into employee(emp_id,emp_age, emp_contact, emp_department, emp_email, emp_gender, emp_name) values(3, 25, 1234567980, 'IT','riya@gmail.com','Female','riya');
insert into employee(emp_id,emp_age, emp_contact, emp_department, emp_email, emp_gender, emp_name) values(4, 25, 1234567980, 'IT','maya@gmail.com','Female','maya');
insert into employee(emp_id,emp_age, emp_contact, emp_department, emp_email, emp_gender, emp_name) values(5, 25, 1234567980, 'IT','arya@gmail.com','Female','arya');


