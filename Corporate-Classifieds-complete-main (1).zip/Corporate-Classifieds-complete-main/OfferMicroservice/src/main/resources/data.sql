insert into offer_category values(120,'Homes');
insert into offer_category values(121,'Vehicles');
insert into offer_category values(122,'Electronics');
insert into offer_category values(123,'Home Appliances');
insert into offer_category values(124,'Mobiles & Tablets');
insert into offer_category values(125,'Furniture & Decors');
insert into offer_category values(126,'Commercial Rentals');
insert into offer_category values(127,'Personals');

insert into offer values(1,'2022-08-22',1,10,'Fridge','2022-07-01',123);
insert into offer values(2,'2022-08-22',2,12,'Laptop','2022-07-01',122);
insert into offer values(3,'2022-08-22',3,14,'Bed','2022-07-01',125);
